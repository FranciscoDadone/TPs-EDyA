//========================================//
// Estructura de Datos y Algoritmos 2015
//=======================================//
#include <iostream>
#include <string>
#include <queue>


using namespace std;
#include "include/arbol_test.h"


int main(void) {
    test_00();
    test_01();
    //test_02();
    return 0;
}
